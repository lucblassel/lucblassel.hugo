# pyright: basic
import torch
import torch.nn.functional as F


def batch_init_NJ(distances, rooted: bool = False):
    device = distances.device
    dists = distances.type(torch.float).to(device=device)
    batch_size, n_leaves, _ = dists.shape

    internal_nodes = n_leaves - 3
    if rooted:
        internal_nodes += 1

    node_count = n_leaves + internal_nodes

    # Init splits matrix
    splits = torch.concatenate(
        [
            torch.eye(n_leaves, dtype=torch.float, device=device),
            torch.zeros((internal_nodes, n_leaves), dtype=torch.float, device=device),
        ]
    ).repeat(batch_size, 1, 1)

    brlens = torch.zeros(
        node_count,
        dtype=torch.float,
        device=device,
    ).repeat(batch_size, 1)

    # Pad distance matrix to add future merged nodes
    dists = F.pad(
        dists,
        pad=(0, internal_nodes, 0, internal_nodes),
        mode="constant",
        value=torch.inf,
    ).masked_fill_(torch.eye(node_count, device=device).bool(), 0.0)

    # Mask to track ignored nodes
    ignored_nodes = torch.full(
        (batch_size, node_count),
        False,
        dtype=torch.bool,
        device=device,
    )
    ignored_nodes[:, n_leaves:] = True

    return (dists, splits, brlens, ignored_nodes, n_leaves, node_count)


def batch_mask_from_ignored(ignored):
    return torch.matmul(
        (~ignored[:, :, None]).float(), (~ignored[:, None, :]).float()
    ).bool()


def batch_compute_merge_logproba(Q, H_i, H_j, ignored, temp=None):
    """
    Given a Q matrix and the 2 nodes to merge, compute the logprobability of merge given Q.
    Optional temprature parameter that will multiply the input to the softmin
    """

    batch_size, _, _ = Q.shape

    mask_2d = batch_mask_from_ignored(ignored)
    # We want 1 version of the Q value for the softmax
    mask_tril = ~(torch.ones_like(Q[0, :]).triu(diagonal=1) != 0)
    mask = torch.logical_or(~mask_2d, mask_tril.unsqueeze(0))

    Q_masked = Q.clone().contiguous()
    Q_masked.masked_fill_(mask, torch.inf)

    if temp is not None:  # Apply temperature
        Q_masked = temp * Q_masked

    all_logprobas = (-Q_masked.view(batch_size, -1)).log_softmax(dim=-1).view(Q.shape)

    merge_logprobas = (
        H_i.unsqueeze(1) @ all_logprobas.masked_fill(mask, 0)
    ) @ H_j.unsqueeze(-1)

    return merge_logprobas.squeeze()


def batch_update_ignored(ignored_nodes, H_i, H_j, u):
    # Udate masked values
    i, j = (
        torch.argmax(H_i, dim=-1),
        torch.argmax(H_j, dim=-1),
    )
    b_idx = torch.arange(ignored_nodes.shape[0])
    ignored_nodes[b_idx, i] = True
    ignored_nodes[b_idx, j] = True
    if u is not None:
        ignored_nodes[b_idx, u] = False

    return ignored_nodes


def argmax(x, axis=-1):
    return F.one_hot(torch.argmax(x, dim=axis), list(x.shape)[axis]).float()


def sample_oh(x, axis=-1):
    return F.one_hot(x.multinomial(num_samples=1), list(x.shape)[axis]).float()


def batch_sample_merge(Q, ignored, temp=None, use_max_proba: bool = False):
    batch_size, _, _ = Q.shape

    mask_2d = batch_mask_from_ignored(ignored)
    # We want 1 version of the Q value for the softmax
    mask_tril = ~(torch.ones_like(Q[0, :]).triu(diagonal=1) != 0)
    mask = torch.logical_or(~mask_2d, mask_tril.unsqueeze(0))

    Q_masked = Q.clone().contiguous()
    Q_masked.masked_fill_(mask, torch.inf)

    if temp is not None:  # Apply temperature
        Q_masked = temp * Q_masked

    all_probas = (-Q_masked.view(batch_size, -1)).softmax(dim=-1)  # .view(Q.shape)

    if use_max_proba:
        flat_onehot = argmax(all_probas)
    else:
        flat_onehot = sample_oh(all_probas)

    batch_size, node_count, _ = Q.shape

    # flat_onehot = argmin(Q.reshape(batch_size, -1))
    square_onehot = flat_onehot.view(Q.shape)
    ones = torch.ones((batch_size, node_count, 1), device=Q.device, dtype=torch.float)
    H_i = torch.matmul(square_onehot, ones).squeeze((1, 2))
    H_j = (
        torch.matmul(ones.transpose(-1, -2), square_onehot)
        .transpose(-1, -2)
        .squeeze((1, 2))
    )

    return H_i, H_j
