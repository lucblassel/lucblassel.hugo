# pyright: basic

from glob import glob
from pathlib import Path

import torch
import torch.nn.functional as F
from dendropy import Node, TaxonNamespace, Tree
from torch.utils.data import Dataset

PADDING_TOKEN = -1

ALPHABET = b"ARNDCQEGHILKMFPSTWYVX-~"  # '~' is the CLS token
LOOKUP = {char: index for index, char in enumerate(ALPHABET)}
IDENT = torch.eye(len(ALPHABET))
# One hot vectors for each character
VECS = {char: IDENT[index] for index, char in enumerate(ALPHABET)}
# X is any of the amino acids (except -)
VECS[ord("X")] = sum(VECS[c] for c in ALPHABET[:-2]) / (len(ALPHABET) - 2)  # type: ignore
# IUPAC: B is D or N
VECS[ord("B")] = (VECS[ord("D")] + VECS[ord("N")]) / 2
# IUPAC: Z is E or Q
VECS[ord("Z")] = (VECS[ord("E")] + VECS[ord("Q")]) / 2


def parse_alignment(stream):
    """
    Parses a fasta formatted alignment from a binary file strean
    """

    sequence_tensors, ids = [], []

    first = True
    currseq = [VECS[ord("~")]]  # Starting the sequence with a [CLS] token
    for line in stream:
        line = line.strip()
        if line.startswith(b">"):
            ids.append(line[1:].decode("utf8"))
            if not first:
                sequence_tensors.append(torch.stack(currseq))
                currseq = [VECS[ord("~")]]
            first = False
        else:
            for char in line:
                # Any unknown characters such as '?' are treated as 'X'
                currseq.append(VECS.get(char, VECS[ord("X")]))

    # Append last sequence to alignment
    sequence_tensors.append(torch.stack(currseq))

    tensor_aln = torch.stack(sequence_tensors).permute(2, 1, 0)

    return tensor_aln, ids


def load_alignment(filepath):
    """
    Reads a fasta formater alignment and returns a one-hot encoded
    tensor of the MSA and the corresponding taxa label order
    """

    with open(filepath, "rb") as stream:
        seqs, ids = parse_alignment(stream)

    return seqs, ids


class MergeOrderDataset(Dataset):
    def __init__(
        self,
        tree_dir: str,
        msa_dir: str,
    ) -> None:
        super().__init__()
        self.tree_dir = tree_dir
        self.msa_dir = msa_dir

        self.tree_msa_pairs = self.find_pairs()

    def find_pairs(self) -> list[tuple[str, str]]:
        trees = {
            Path(treepath).stem: treepath
            for ext in ["nwk", "newick"]
            for treepath in glob(f"{self.tree_dir}/*{ext}")
        }
        msas = {
            Path(msapath).stem: msapath
            for ext in ["fa", "fasta"]
            for msapath in glob(f"{self.msa_dir}/*{ext}")
        }

        pairs = []
        for id_, treepath in trees.items():
            if (msapath := msas.get(id_)) is not None:
                pairs.append((treepath, msapath))

        return pairs

    def __len__(self) -> int:
        return len(self.tree_msa_pairs)

    def __getitem__(self, index):
        treepath, msapath = self.tree_msa_pairs[index]
        msa, ids = load_alignment(msapath)
        merge_order, brlens = get_merge_order(treepath, ids)

        return msa, merge_order, brlens, ids


def get_merge_order(treepath, ids):
    ns = TaxonNamespace(x.replace("_", " ") for x in ids)
    tip_order = {t: i for i, t in enumerate(ns)}

    n_leaves = len(ids)
    n_nodes = 2 * n_leaves - 1

    brlens = [None for _ in ids]

    tree: Tree = Tree.get_from_path(treepath, schema="newick", taxon_namespace=ns)
    assert len(tree.seed_node.child_nodes()) == 2, "Only applicaple to rooted trees"

    # Pre-compute cherry lengths
    nodes = {}
    for node in tree.postorder_node_iter():
        if node.is_leaf():
            node.label = tip_order[node.taxon]
            brlens[tip_order[node.taxon]] = node.edge_length
            nodes[node] = NodeWrapper(0.0, is_cherry=False, is_merged=True)
        else:
            is_cherry = all(n.is_leaf() for n in node.child_node_iter())
            cherry_len = sum(e.length for e in node.child_edge_iter())
            nodes[node] = NodeWrapper(cherry_len, is_cherry=is_cherry, is_merged=False)

    # Compute merge order
    merge_order = []
    for i in range(n_nodes - n_leaves):
        u = len(ids) + i

        node_to_merge = find_node_to_merge(nodes)

        merge_order.append(
            tuple(sorted([n.label for n in node_to_merge.child_node_iter()]))
        )

        node_to_merge.label = u

        nodes[node_to_merge].is_cherry = False
        nodes[node_to_merge].is_merged = True

        # Check if parent is new cherry
        parent = node_to_merge.parent_node
        if parent is not None:
            nodes[parent].is_cherry = all(
                nodes[k].is_merged for k in parent.child_node_iter()
            )
            brlens.append(node_to_merge.edge_length)
        else:
            assert i == n_leaves - 2, "Merging root before other nodes..."

    return (
        F.one_hot(torch.tensor(merge_order), num_classes=n_nodes - 1),
        torch.tensor(brlens),
    )


class NodeWrapper:
    def __init__(
        self, cherry_len: float, is_cherry: bool = False, is_merged: bool = False
    ) -> None:
        self.len = cherry_len
        self.is_cherry = is_cherry
        self.is_merged = is_merged

    def __repr__(self) -> str:
        if self.is_cherry:
            s = f"C({self.len})"
        else:
            s = f"N({self.len})"
        if self.is_merged:
            s += "|X"
        return s


def find_node_to_merge(nodes: dict[Node, NodeWrapper]) -> Node:
    min_node = None
    min_info = None

    for node, info in nodes.items():
        if not info.is_cherry:
            continue

        if min_node is None:
            min_node = node
            min_info = info
            continue

        if info.len < min_info.len:  # type: ignore
            min_node = node
            min_info = info

    assert min_node is not None

    return min_node
