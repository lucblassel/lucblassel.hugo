# pyright: basic

import math

import torch
import torch.nn.functional as F
from torch import Tensor, nn
from torch.nn.utils import parametrize


class Symmetric(nn.Module):
    def forward(self, X):
        return (X + X.transpose(-1, -2)) / 2


class ParamsFromPair(nn.Module):
    def __init__(
        self,
        d_msa: int,
        n_params: int,
        symmetric: bool = False,
    ):
        super().__init__()
        self.bil = nn.Bilinear(
            in1_features=d_msa, in2_features=d_msa, out_features=n_params
        )
        if symmetric:
            parametrize.register_parametrization(self.bil, "weight", Symmetric())

    def forward(self, seq1: Tensor, seq2: Tensor) -> Tensor:
        return self.bil(seq1, seq2)


class ParentEmbedder(nn.Module):
    def __init__(self, msa_dim: int):
        super().__init__()
        self.msa_dim = msa_dim
        self.bil = ParamsFromPair(msa_dim, msa_dim, symmetric=True)

    def forward(self, seq1: Tensor, seq2: Tensor):
        return self.bil(seq1, seq2)


class PairProbaSampler(nn.Module):
    def __init__(self, msa_dim: int):
        super().__init__()
        self.msa_dim = msa_dim

        self.bil = ParamsFromPair(msa_dim, 1, symmetric=True)

        nn.init.xavier_uniform_(self.bil.bil.parametrizations.weight.original)
        nn.init.constant_(self.bil.bil.bias, 0.0)

    def forward(self, seqs1: Tensor, seqs2: Tensor):
        return self.bil(seqs1, seqs2)


def seq2pairs(n, lower=False, diff=False):
    """
    Gives a matrix which will transform from sequence space to pair space:

     - If lower=True, then the order of the pairs corresponds to the order
     of the lower triangular vector of the pairwise matrix. By default the
     order corresponds to the upper triangular vector

     - If diff=True, then multiplying this matrix with the MSA embedding
     will yield the difference between embeddings instead of the sum by
     default (e.g. useful if computing pairwise distances)
    """
    n_pairs = n * (n - 1) // 2
    seq2pair = torch.zeros(n_pairs, n)

    # Compute where to put 1
    row_idx = torch.arange(n_pairs).long()

    idx = torch.triu_indices(n, n, offset=1)
    if lower:
        idx = torch.tril_indices(n, n, offset=-1)

    # Define fill values
    fill = torch.Tensor([1])
    fill2 = fill * (-1 if diff else 1)

    # Fill the matrix and return
    seq2pair = seq2pair.index_put((row_idx, idx[0]), fill)
    return seq2pair.index_put((row_idx, idx[1]), fill2)


class ColAttenPairBias(nn.Module):
    def __init__(
        self,
        msa_dim: int,
        pairs_dim: int,
        n_heads: int,
    ) -> None:
        super().__init__()
        self.embed_dim = msa_dim
        self.pairs_dim = pairs_dim
        self.n_heads = n_heads

        self.head_dim = msa_dim // n_heads
        self.sqrt_dim = math.sqrt(self.head_dim)

        # Layer norms
        self.msa_norm = nn.LayerNorm(msa_dim)
        self.pairs_norm = nn.LayerNorm(pairs_dim)

        # Input projectors
        self.q_proj = nn.Linear(msa_dim, msa_dim, bias=False)
        self.k_proj = nn.Linear(msa_dim, msa_dim, bias=False)
        self.v_proj = nn.Linear(msa_dim, msa_dim, bias=False)
        self.g_proj = nn.Linear(msa_dim, msa_dim, bias=True)
        self.b_proj = nn.Linear(pairs_dim, n_heads, bias=False)

        # Output projector
        self.out_proj = nn.Linear(msa_dim, msa_dim)

    def forward(self, msa, pairs):
        # MSA: [B,d_m,n,L]
        # Pairs: [B,n,n,d_p] (or [B,nC2,d_p] is symmetric)
        B, d_m, n, L = msa.size()
        H = self.n_heads
        d_h = self.head_dim
        sqrt_c = self.sqrt_dim

        # Normalize
        msa = self.msa_norm(msa.transpose(-1, -3))  # [B,L,n,d_m]
        pairs = self.pairs_norm(pairs)  # [B,n,n,d_p] ([B,nC2,d_p])

        # pair bias: [B,n,n,H] ([B,nC2,H])
        b = self.b_proj(pairs)

        # Input projections
        # projections: [b,L,H,n,d_h]
        q = self.q_proj(msa).reshape(B, L, n, H, d_h).transpose(2, 3)
        k = self.k_proj(msa).reshape(B, L, n, H, d_h).transpose(2, 3)
        v = self.v_proj(msa).reshape(B, L, n, H, d_h).transpose(2, 3)

        # gating: [b,L,H,n,d_h]
        g = F.sigmoid(self.g_proj(msa).reshape(B, L, n, H, d_h).transpose(2, 3))

        # Attention
        # [B,L,H,n,n]
        qkdiv = (q @ k.transpose(-1, -2)) / sqrt_c

        biased = qkdiv
        b = b.transpose(-1, -2).unsqueeze(1)
        ix, jx = torch.tril_indices(n, n, -1)

        # Add to lower tri
        biased[:, :, :, ix, jx] += b
        # Add to upper tri
        biased = biased.transpose(-1, -2)
        biased[:, :, :, ix, jx] += b
        # Undo transpose
        biased = biased.transpose(-1, -2)

        attn_weights = biased.softmax(-1)
        attn_out = g * (attn_weights @ v)

        attn_out = attn_out.transpose(2, 3).reshape(B, L, n, d_m)

        # [B,L,n,d_m]
        out = self.out_proj(attn_out)

        # [B,d_m,n,L]
        return out.permute(0, 3, 2, 1)


class RowAttenGated(nn.Module):
    def __init__(self, msa_dim: int, n_heads: int) -> None:
        super().__init__()

        self.msa_dim = msa_dim
        self.n_heads = n_heads

        self.mha = nn.MultiheadAttention(msa_dim, n_heads, batch_first=True, bias=False)
        self.norm = nn.LayerNorm(msa_dim)
        self.g_proj = nn.Linear(msa_dim, msa_dim)
        self.out_proj = nn.Linear(msa_dim, msa_dim)

    def forward(self, msa):
        B, d_m, n, L = msa.size()

        # [B,L,n,d_m] -> [B*n,L,d_m]
        msa = self.norm(msa.transpose(-1, -3))
        r = msa.transpose(-2, -3).reshape(B * n, L, d_m)
        # gating: [B*n,L,d_m]
        g = F.sigmoid(self.g_proj(r))

        attn_out, _ = self.mha(r, r, r, need_weights=False)
        attn_out = (g * attn_out).reshape(B, n, L, d_m)

        # [B,n,L,d_m]
        out = self.out_proj(attn_out)

        # [B,d_m,n,L]
        return out.permute(0, 3, 1, 2)


class Transition(nn.Module):
    def __init__(self, dim: int) -> None:
        super().__init__()
        self.dim = dim

        self.norm = nn.LayerNorm(dim)
        self.expand = nn.Linear(dim, dim * 4)
        self.relu = nn.ReLU()
        self.contract = nn.Linear(dim * 4, dim)

    def default_fwd(self, input):
        return self.contract(self.relu(self.expand(self.norm(input))))

    def forward(self, input):
        return self.default_fwd(input)


class MSATransition(Transition):
    def __init__(self, dim: int) -> None:
        super().__init__(dim)

    def forward(self, input):
        # [B,d_m,n,L] -> [B,n,L,d_m]
        msa = input.transpose(-1, -3)
        msa = self.default_fwd(msa)

        # back to [B,d_m,n,L]
        return msa.transpose(-1, -3)


class PairTransision(Transition):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)


class OuterProductMean(nn.Module):
    def __init__(self, msa_dim: int, pair_dim: int, inner_dim: int) -> None:
        super().__init__()
        self.norm = nn.LayerNorm(msa_dim)
        self.a_proj = nn.Linear(msa_dim, inner_dim)
        self.o_proj = nn.Linear(inner_dim**2, pair_dim)

    def forward(self, msa):
        # MSA: [B,d_m,n,L]
        _, _, n, L = msa.size()

        # [B,L,n,d_m]
        msa = self.norm(msa.transpose(-1, -3))

        # [B,n,L,d_in]
        a = self.a_proj(msa).transpose(-2, -3)

        # [B,n,n,d_in,d_in]
        outer_prod = torch.einsum("...nld,...NlD->...nNdD", a, a) / L
        i, j = torch.tril_indices(n, n, -1)
        # [B,nC2,d_in,d_in]
        outer_prod = outer_prod[:, i, j, :, :]

        # [B,n,n,d_in*d_in] (or [B,nC2,d_in*d_in])
        o = outer_prod.reshape(outer_prod.shape[:-2] + (-1,))

        return self.o_proj(o)


class PairAttention(nn.Module):
    def __init__(self, pair_dim: int, n_heads: int) -> None:
        super().__init__()
        self.pair_dim = pair_dim
        self.n_heads = n_heads

        self.norm = nn.LayerNorm(pair_dim)
        self.mha = nn.MultiheadAttention(
            pair_dim, n_heads, batch_first=True, bias=False
        )
        self.g_proj = nn.Linear(pair_dim, pair_dim)
        self.out_proj = nn.Linear(pair_dim, pair_dim)

    def forward(self, pairs):
        # Pairs: [B,nC2,d_p]

        r = self.norm(pairs)
        g = self.g_proj(r)
        out, _ = self.mha(r, r, r, need_weights=False)
        out = g * out

        return self.out_proj(out)


class EvoPFBlock(nn.Module):
    def __init__(
        self,
        msa_dim: int,
        pair_dim: int,
        n_heads: int,
    ) -> None:
        super().__init__()
        self.msa_dim = msa_dim
        self.pairs_dim = pair_dim
        self.n_heads = n_heads

        # MSA stack
        self.row_atten = RowAttenGated(msa_dim, n_heads)
        self.col_atten = ColAttenPairBias(msa_dim, pair_dim, n_heads)
        self.msa_trans = MSATransition(msa_dim)

        # Pair stack
        self.pair_update = OuterProductMean(msa_dim, pair_dim, 32)
        self.pair_atten = PairAttention(pair_dim, n_heads)
        self.pair_trans = Transition(pair_dim)

    def forward(self, msa, pairs):
        # MSA: [B,d_m,n,L]
        # Pairs: [B,n,n,d_p]

        ## MSA STACK
        # Col-Wise attention w/ pair biases
        res = msa
        msa = self.col_atten(msa, pairs) + res

        # Row-size attention
        res = msa
        msa = self.row_atten(msa) + res

        # MSA Transition
        res = msa
        msa = self.msa_trans(msa) + res

        ## PAIR STACK
        # Outer product mean to update pairs
        res = pairs
        pairs = self.pair_update(msa) + res

        # Apply self attention to pairs
        res = pairs
        pairs = self.pair_atten(pairs) + res

        # Pair transition
        res = pairs
        pairs = self.pair_trans(pairs) + res

        return msa, pairs


class MSAEmbedder(nn.Module):
    def __init__(self, embed_dim: int) -> None:
        super().__init__()
        self.block = nn.Sequential(
            nn.Conv2d(in_channels=23, out_channels=embed_dim, kernel_size=1, stride=1),
            nn.ReLU(),
        )

    def forward(self, input):
        # [B,d,L,n]
        out = self.block(input)

        # [B,D,n,L]
        return out.transpose(-1, -2)


class PairEmbedder(nn.Module):
    def __init__(self, pair_dim: int) -> None:
        super().__init__()
        self.embedder = nn.Sequential(
            nn.Conv2d(in_channels=23, out_channels=pair_dim, kernel_size=1, stride=1),
            nn.ReLU(),
        )

    def forward(self, msa):
        msa_emb = self.embedder(msa)  # [b,d_p,L,n]
        s2p = seq2pairs(msa.size(-1), lower=True, diff=False).to(msa)  # [nC2,n]
        pair_sums = msa_emb @ s2p.T  # [b,d_p,L,nC2]
        pairs = pair_sums.mean(dim=-2)  # [b,d_p,nC2]

        return pairs.permute(0, 2, 1)  # [d,nC2,d_p]


class EvoPF(nn.Module):
    def __init__(
        self,
        n_blocks: int = 6,
        n_heads: int = 4,
        h_dim: int = 64,
        pair_dim: int = 256,
        use_opm: bool = True,
        distance_mlp: bool = False,
        symmetric: bool = False,
        use_deepspeed: bool = False,
        use_flexattention: bool = False,
        use_bilinear_embedder: bool = False,
    ):
        super().__init__()
        self.symmetric = symmetric
        self.msa_embedder = MSAEmbedder(h_dim)
        self.pair_embedder = PairEmbedder(pair_dim)
        self.evoblocks = nn.ModuleList(
            [
                EvoPFBlock(
                    h_dim,
                    pair_dim,
                    n_heads,
                )
                for _ in range(n_blocks)
            ]
        )

    def embed_input(self, input):
        # [b,d_m,n,L]
        msa_emb = self.msa_embedder(input)
        # [b,n,n,d_p]
        pairs = self.pair_embedder(input)

        return msa_emb, pairs

    def forward(self, input):
        msa, pairs = self.embed_input(input)

        for block in self.evoblocks:
            msa, pairs = block(msa, pairs)

        # Compute distances
        dm = self.pairs_to_dm(pairs).squeeze(-1)
        if not self.symmetric:
            dm = (dm + dm.transpose(-1, -2)) / 2.0

        if self.output_msa_emb:
            msa_emb = msa.mean(-1)
            return dm, msa_emb

        return dm
